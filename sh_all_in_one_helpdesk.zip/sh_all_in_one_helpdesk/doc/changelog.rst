16.0.1 ( Date : 11 Oct 2022 )
-----------------------------------
Initial Release

16.0.2 (Date : 18th Jan 2023)
-----------------------------------
[FIX] - ticket not create from incoming mail

16.0.3 (Date : 7th Feb 2023)
-----------------------------------
[FIX] - Customer rating issue fix on ticket

16.0.4 (Date : 24 Feb 2023)
-----------------------------------
[FIX] : multi-user can start ticket timer parallel,Real Duration issue fix at multi-user. 

16.0.5 (Date : 13th March 2023)
---------------------------------
[FIX] Translation error while installing the module.

16.0.6 (Date : 4th April 2023)
------------------------------------------------
[FIX] Portal User can't access attachments

16.0.7 (Date : 29th May 2023)
--------------------------
Fix - issue of background color in dropdown in ticket dashboard.

16.0.8 (Date : 09th Jun 2023)
--------------------------
Fix - issue of user can start multiple ticket timer at a time.
Add - allow multiple users can start one ticket if allow mutiple ticket users

16.0.9 (Date : 15th June 2023)
===================================================================
[UPDATE] - Add configuration for Munual add Timesheet in ticket

16.0.10 (Date : 11th Sep 2023)
===================================================================
Small Bug Fixes Related to Portal and Access Rights
-----------------------------------------------------
1) In Portal user can show Helpdesk Ticket Menu 
2) Portal flow with portal access field added in the user profile view
3) Actually need to set default team with current login user as portal user with portal access field from the user
4) Update Code for Assign Multi Users multi selected
5) Update Code for Set default team when support-user create ticket 
6) Remove create button from stage change history

16.0.11 (Date : 26th Oct 2023)
-------------------------------
[FIX] Fix issue of French language Translation.