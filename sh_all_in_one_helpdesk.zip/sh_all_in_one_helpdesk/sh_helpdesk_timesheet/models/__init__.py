# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from . import res_config_setting
from . import helpdesk_ticket
from . import hr_timesheet
from . import res_users
