/** @odoo-module **/
import { _t } from "@web/core/l10n/translation";
import { KanbanRenderer } from "@web/views/kanban/kanban_renderer";
import { useService } from "@web/core/utils/hooks";

const rpc = useService("rpc");

KanbanRenderer.include({
    events: Object.assign({}, KanbanRenderer.prototype.events, {
        "click .sh_tile_click": "action_all_tickets",
    }),

    async action_all_tickets(event) {
        console.log("clicked");
        event.stopPropagation();
        event.preventDefault();
        const self = this;
        const $el = $(event.currentTarget).attr("data-res_ids");

        try {
            const actionData = await rpc({
                model: "ir.model.data",
                method: "xmlid_to_res_model_res_id",
                args: ["sh_all_in_one_helpdesk.sh_helpdesk_ticket_form_view"],
            });

            const domain = $el === undefined ? [] : ["id", "in", JSON.parse($el)];

            self.do_action({
                name: _t("Tickets"),
                type: "ir.actions.act_window",
                res_model: "sh.helpdesk.ticket",
                view_mode: "kanban,tree,form",
                views: [
                    [false, "kanban"],
                    [false, "list"],
                    [actionData[1], "form"],
                ],
                domain: domain,
                target: "current",
            });
        } catch (error) {
            console.error("Failed to perform action:", error);
            // Handle the error appropriately
        }
    },
});